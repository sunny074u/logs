#!/bin/bash

tail -f /opt/gen_logs/logs/access.log
